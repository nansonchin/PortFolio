import { useTerminalScroll } from "../../hooks/useTerminalScroll";
import type { TerminalMessage } from "../../types/terminal.types";
import TerminalInput from "./TerminalInput";

type TerminalPanelProps = {
  history: TerminalMessage[];

  command: string;

  onChangeCommand: (value: string) => void;

  onHistoryNavigate: (direction: "up" | "down") => void;

  onSubmit: () => void;

  onClose: () => void;
};

function renderText(text: string) {
  return text.split(/(https?:\/\/\S+)/g).map((part, i) =>
    /^https?:\/\//.test(part) ? (
      <a
        key={i}
        href={part}
        target="_blank"
        rel="noopener noreferrer"
        className="underline underline-offset-2 hover:text-white"
      >
        {part}
      </a>
    ) : (
      part
    ),
  );
} 

export default function TerminalPanel({
  history,

  command,

  onChangeCommand,

  onHistoryNavigate,

  onSubmit,

  onClose,
}: TerminalPanelProps) {
  const terminalRef = useTerminalScroll(history);

  return (
    <section
    data-lenis-prevent
      id="portfolio-terminal"
      role="dialog"
      aria-modal="false"
      aria-labelledby="terminal-title"
      className="
      fixed
      bottom-24
      left-4
      z-[9999]
      flex
      h-[min(500px,65vh)]
      w-[min(92vw,480px)]
      flex-col
      overflow-hidden
      rounded-xl
      border
      border-[#C9A96E]/40
      bg-[#090909]
      text-[#F5F5F5]
      shadow-[0_20px_80px_rgba(0,0,0,0.65)]
      "
    >
      {/* Header */}

      <header
        className="
        flex
        items-center
        justify-between
        border-b
        border-[#C9A96E]/20
        bg-[#101010]
        px-4
        py-3
        "
      >
        <div
          className="
          flex
          items-center
          gap-3
          "
        >
          <div
            className="
            flex
            gap-1.5
            "
          >
            <span
              className="
              h-2.5
              w-2.5
              rounded-full
              bg-[#D8BD83]
              "
            />

            <span
              className="
              h-2.5
              w-2.5
              rounded-full
              bg-[#555]
              "
            />

            <span
              className="
              h-2.5
              w-2.5
              rounded-full
              bg-[#555]
              "
            />
          </div>

          <h2
            id="terminal-title"
            className="
            text-xs
            font-medium
            tracking-[0.15em]
            text-[#D8BD83]
            "
          >
            DEVELOPER TERMINAL
          </h2>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="
          rounded
          px-2
          py-1
          text-lg
          text-neutral-400
          hover:bg-white/10
          hover:text-white
          "
        >
          ×
        </button>
      </header>

      {/* Output */}

      <div
        ref={terminalRef}
        className="
        min-h-0
        flex-1
        overflow-y-auto
        px-4
        py-4
        font-mono
        text-xs
        leading-6
        sm:text-sm
        "
      >
        <p
          className="
          mb-3
          text-[#D8BD83]
          "
        >
          Portfolio System
          <span className="text-neutral-500">[UI]</span>
        </p>

        {history.map((message) => (
          <p
            key={message.id}
            className={`
                  break-words whitespace-pre-wrap

                  ${
                    message.type === "command"
                      ? "text-[#F5F5F5]"
                      : message.type === "success"
                        ? "text-[#D8BD83]"
                        : message.type === "error"
                          ? "text-red-400"
                          : "text-neutral-400"
                  }

                  `}
          >
           {renderText(message.text)}
          </p>
        ))}
      </div>

      <TerminalInput
        value={command}
        onChange={onChangeCommand}
        onSubmit={onSubmit}
        onHistoryNavigate={onHistoryNavigate}
      />

      <footer
        className="
        border-t
        border-white/5
        px-4
        py-2
        text-[10px]
        text-neutral-600
        "
      >
        ESC TO CLOSE
      </footer>
    </section>
  );
}
